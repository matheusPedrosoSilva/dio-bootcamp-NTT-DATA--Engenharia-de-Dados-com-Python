# pacote-processamento-imagem.py

## Descrição
Esse é um pacote de processamento de imagens que te possibilita:
    **Processos**:
        + Criar um histograma;
        + Fazer a comparação entre duas imagens;
        + Redimensionar o tamanho de uma imagem.
    **Utilidades**:
        + Lê um imagem;
        + Salva uma image;
## Instalação
Use este package manager [pip](https://pip.pyna.io/en/stable/) para instalar o image_processing

```bash
pip install image_processing
```

## Autor
Matheus Pedroso da Silva